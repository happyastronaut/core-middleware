var neon = require('@cityofzion/neon-js')
var Neon = neon.default
const neo = require("./backend/blockchain.js")
const account = require("./backend/config.js")
const util = require("./backend/util.js")
const tools = require("./backend/tools.js")

switch (process.argv[2]) {
  case "name":
    name()
    break
  default:
    console.log("fail arg")
}

function name() {
  neo.getValue("name", account.address).then((res) => {
    var fs = require('fs')
    if(res != ""){
      fs.writeFile("./masterIP", res, function(err) {
          if(err) {
              return console.log(err)
          }
          console.log(res);
          console.log("The file was saved!")
      })
    }
    else {
      fs.writeFile("./masterIP", "NULL", function(err) {
          if(err) {
              return console.log(err)
          }
          console.log("The file was saved!")
      })
      console.log("no value returned");
    }
  })
}



// tools.getExtIP().then((ip) => {
//   neo.invokeContract("registertask", account.address, ip).then((res) => {
//     console.log(res);
//   })
// })


// function getSmartContractValue() {
//   const props = {
//     scriptHash: account.scriptHash,
//     operation: "name",
//     args: []
//   }
//   const script = Neon.create.script(props)
//   return neon.rpc.Query.invokeScript(script)
//     .execute(account.endpoint)
//     .then(function (res) {
//       return util.hex2str(res.result.stack[0].value)
//     })
// }


// tools.getExtIP().then((ip) => {
//
// })
//
// neo.getStorageValue("readtask", account.address).then((res) => {
//   var fs = require('fs')
//   fs.writeFile("./masterIP", res, function(err) {
//       if(err) {
//           return console.log(err)
//       }
//       console.log("The file was saved!")
//   })
// })

// tools.getExtIP().then((ip) => {
//   neo.invokeContract("registertask", account.address, ip).then((res) => {
//     console.log(res);
//   })
// })

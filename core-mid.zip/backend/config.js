module.exports = {
  endpoint: "http://seed3.neo.org:20332",
  net: "TestNet",
  scriptHash:"7957ae94e1c00e756da02e50097a865304ff9668",
  address: "AK9cP6LdpjuaQguvahFA7ojMiDbt4gEdAK",
  wif: "KzkMhXozFKQUfYHQgU8SkSvWm4SBT977wMDqvkBKh1d7Fme6Ft8W"
}
